import Home from "../pages/home/Home";

export default function page() {
  return <Home />;
}
